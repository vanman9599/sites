def to_stringified_float(int)
    return int.to_f.to_s
end

print to_stringified_float(8)